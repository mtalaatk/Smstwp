package com.example.smstowhatsapp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var senderInput: EditText
    private lateinit var keywordInput: EditText
    private lateinit var recipientInput: EditText
    private lateinit var enabledCheck: CheckBox
    private val prefs by lazy { getSharedPreferences("rules", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNeededPermissions()
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(12))
        }
        content.addView(TextView(this).apply {
            text = "إعدادات تحويل الرسائل"
            textSize = 24f
        }, match())
        content.addView(TextView(this).apply {
            text = "اكتب رقم المرسل كما يظهر في الرسالة، والكلمة المطلوبة، ورقم واتساب المستلم بصيغة دولية من دون +."
            textSize = 15f
            setPadding(0, dp(10), 0, dp(18))
        }, match())

        senderInput = field("المرسل (رقم أو Sender ID)", prefs.getString("sender", "") ?: "")
        keywordInput = field("الكلمة المطلوبة داخل الرسالة", prefs.getString("keyword", "") ?: "")
        recipientInput = field("رقم واتساب المستلم، مثال 9665xxxxxxxx", prefs.getString("recipient", "") ?: "")
        recipientInput.inputType = InputType.TYPE_CLASS_PHONE
        content.addView(senderInput, marginTop(dp(8)))
        content.addView(keywordInput, marginTop(dp(8)))
        content.addView(recipientInput, marginTop(dp(8)))

        enabledCheck = CheckBox(this).apply {
            text = "تفعيل مراقبة الرسائل"
            isChecked = prefs.getBoolean("enabled", false)
        }
        content.addView(enabledCheck, marginTop(dp(12)))
        content.addView(TextView(this).apply {
            text = "الخصوصية وطريقة العمل: تتم المطابقة على الجهاز فقط. عند التطابق يظهر إشعار؛ اضغط «مشاركة على واتساب» لفتح واتساب والرسالة جاهزة، ثم اضغط إرسال بنفسك. لا يرسل التطبيق الرسائل سرًا أو تلقائيًا."
            textSize = 14f
            setPadding(0, dp(12), 0, dp(12))
        }, match())
        val save = Button(this).apply {
            text = "حفظ الإعدادات"
            setOnClickListener {
                val sender = senderInput.text.toString().trim()
                val keyword = keywordInput.text.toString().trim()
                val recipient = recipientInput.text.toString().trim().replace("+", "").replace(" ", "")
                if (enabledCheck.isChecked && (sender.isEmpty() || keyword.isEmpty() || recipient.isEmpty())) {
                    Toast.makeText(this@MainActivity, "أكمل الحقول الثلاثة أو أوقف المراقبة.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                prefs.edit()
                    .putString("sender", sender)
                    .putString("keyword", keyword)
                    .putString("recipient", recipient)
                    .putBoolean("enabled", enabledCheck.isChecked)
                    .apply()
                Toast.makeText(this@MainActivity, "تم حفظ الإعدادات", Toast.LENGTH_SHORT).show()
            }
        }
        content.addView(save, marginTop(dp(10)))
        content.addView(Button(this).apply {
            text = "اختبار فتح واتساب"
            setOnClickListener {
                val target = recipientInput.text.toString().trim().replace("+", "").replace(" ", "")
                if (target.isBlank()) {
                    Toast.makeText(this@MainActivity, "أدخل رقم المستلم أولاً.", Toast.LENGTH_SHORT).show()
                } else {
                    ShareActivity.openShare(this@MainActivity, target, "هذه رسالة اختبار من تطبيق SMS إلى واتساب.")
                }
            }
        }, marginTop(dp(8)))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf(Manifest.permission.RECEIVE_SMS)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 100)
    }

    private fun field(hintText: String, value: String) = EditText(this).apply {
        hint = hintText
        setText(value)
        textSize = 16f
        singleLine = true
        setPadding(24, 22, 24, 22)
        setBackgroundResource(android.R.drawable.edit_text)
    }

    private fun match() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun marginTop(top: Int) = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        topMargin = top
    }
}
