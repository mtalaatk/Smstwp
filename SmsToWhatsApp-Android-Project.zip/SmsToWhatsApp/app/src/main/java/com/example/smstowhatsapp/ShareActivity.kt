package com.example.smstowhatsapp

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import java.net.URLEncoder

class ShareActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val recipient = intent.getStringExtra(EXTRA_RECIPIENT).orEmpty()
        val message = intent.getStringExtra(EXTRA_MESSAGE).orEmpty()
        openShare(this, recipient, message)
        finish()
    }

    companion object {
        const val EXTRA_RECIPIENT = "recipient"
        const val EXTRA_MESSAGE = "message"

        fun openShare(context: Context, recipient: String, message: String) {
            // WhatsApp's official click-to-chat link opens the chat with a prefilled message.
            // The user must review and tap Send; Android does not permit reliable silent UI automation.
            val encoded = URLEncoder.encode(message, "UTF-8")
            val uri = Uri.parse("https://wa.me/${recipient.replace("+", "").replace(" ", "")}?text=$encoded")
            val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(intent)
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(context, "تعذر فتح واتساب. تأكد من تثبيته واتصال الإنترنت.", Toast.LENGTH_LONG).show()
            } catch (_: Exception) {
                Toast.makeText(context, "تعذر فتح واتساب.", Toast.LENGTH_LONG).show()
            }
        }
    }
}
