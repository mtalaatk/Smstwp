package com.example.smstowhatsapp

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Telephony
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val prefs = context.getSharedPreferences("rules", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return

        val wantedSender = prefs.getString("sender", "").orEmpty().trim()
        val keyword = prefs.getString("keyword", "").orEmpty().trim()
        val recipient = prefs.getString("recipient", "").orEmpty().trim()
        if (wantedSender.isEmpty() || keyword.isEmpty() || recipient.isEmpty()) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isEmpty()) return
        val actualSender = messages.first().displayOriginatingAddress.orEmpty()
        val body = messages.joinToString(separator = "") { it.messageBody.orEmpty() }

        // Exact sender match ignoring spaces and a leading plus; keyword is case-insensitive.
        if (normalize(actualSender) != normalize(wantedSender)) return
        if (!body.contains(keyword, ignoreCase = true)) return

        createChannel(context)
        val shareIntent = Intent(context, ShareActivity::class.java).apply {
            putExtra(ShareActivity.EXTRA_RECIPIENT, recipient)
            putExtra(ShareActivity.EXTRA_MESSAGE, "رسالة من $actualSender:\n$body")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val pending = PendingIntent.getActivity(
            context, (System.currentTimeMillis() % Int.MAX_VALUE).toInt(), shareIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.sym_action_chat)
            .setContentTitle("تم العثور على رسالة مطابقة")
            .setContentText("اضغط لمراجعة الرسالة ومشاركتها على واتساب.")
            .setStyle(NotificationCompat.BigTextStyle().bigText("المرسل: $actualSender\nتطابقت الكلمة المحددة. اضغط للمشاركة يدويًا."))
            .setContentIntent(pending)
            .addAction(android.R.drawable.sym_action_chat, "مشاركة على واتساب", pending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        try {
            NotificationManagerCompat.from(context).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
        } catch (_: SecurityException) {
            // Notifications may be disabled by the user; no background sending is attempted.
        }
    }

    private fun normalize(s: String) = s.trim().replace("+", "").replace(" ", "")
    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "رسائل SMS المطابقة", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    companion object { const val CHANNEL_ID = "matching_sms" }
}
